import numpy as np
import matplotlib.pyplot as plt
import matplotlib.lines as lines
import matplotlib.patches as patches
import matplotlib.path as path
from scipy.interpolate import *
from pylab import * 
from collections import namedtuple
from collections import defaultdict

import re





def readTempHTMLFile(str):
    file = open(str, 'r')
    tempDict = defaultdict()
    
    reachedEnd = False
    
    #skip first four lines using List Comprehension
    [file.readline().strip for i in range(5)]
    
    while(reachedEnd == False):
        
        string1 = file.readline().strip()
       # print(string1)
        if(re.search('</TABLE>', string1) == None):   
            
            #Finding year number
            yearRegEx = re.compile(r'\d\d\d\d<')
            
            matches1 = yearRegEx.findall(string1);
            strYear = matches1[0]
            strYear = strYear[0:4]
            
            
            #Finding median temperature
            tempRegEx = re.split('</TD><TD>', string1)
            median = (float)(tempRegEx[1])
            
            
            #Put year and median into default dictionary
            tempDict[strYear] = median
            
        else:
            reachedEnd = True
            
    return tempDict



    


def createXYPlot(tempDict):

    years = []
    medians = []
    for key2 in tempDict:
        year = (int)(key2)
        years.append(year)
        medians.append(tempDict[key2])
    
    plt.plot(years, medians)
    plt.xlabel("Years")
    plt.ylabel("Degrees(Celcius)")
    plt.title("XY Plot")
    plt.show()
    

def createBarChart(tempDict):
    years = []
    medians = []
    for key2 in tempDict:
        year = (int)(key2)
        years.append(year)
        medians.append(tempDict[key2])
        
    plt.figure(figsize = (9,3))
    plt.subplot(131)
    plt.bar(years, medians)
    plt.xlabel("Years")
    plt.ylabel("Degrees(Celcius)")
    plt.title("Bar Chart")
    plt.show()
    
  

def createLinearRegression(tempDict):
    years = []
    medians = []
    yearsIntegers = []
    for key2 in tempDict:
        year = (int)(key2)
        years.append(year)
        yearsIntegers.append(year-1850)
        medians.append(tempDict[key2])
    
    
    coef= np.polyfit(years, medians, 1)
    poly1d_fn = np.poly1d(coef)
    
    plt.plot(years,medians, 'yo',years, poly1d_fn(years))
    plt.show()
    print("y=",coef[0],"x", coef[1])
   
   


    
    
    
    
    
    
    
    
    
    
    
    




