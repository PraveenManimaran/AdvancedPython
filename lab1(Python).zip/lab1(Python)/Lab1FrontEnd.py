import Lab1BackEnd
from tkinter import *
import tkinter.messagebox
import sqlite3
from tkinter import messagebox
from collections import namedtuple
from collections import defaultdict

import re

tempDict = defaultdict()

#CHANGE PATH NAME!!!
tempDict = Lab1BackEnd.readTempHTMLFile("/Users/praveenmanimaran/Desktop/Temperature.html")

def main():  

    root = Tk()
    root.geometry("400x200")
    
    root.title("Select The Graph You Want To Display")
    options = ["XY Plot","Bar Chart","Linear Regression"]
    var = StringVar()
    menu = OptionMenu(root,var,*options,command=selected)
    menu.place(x=1,y=1)

    root.mainloop()
    
    #SQL Functions
    connectToDataBase()
    createTable()
    year = 0
    median = 0.0
    count = 1
    for key2 in tempDict:
        year = (int)(key2)
        median = tempDict[key2]
        insert(count, year,median )
        count+=1
   

def connectToDataBase():
    try:
        sqliteConnection = sqlite3.connect('Lab1_SQLite.db')
        cursor = sqliteConnection.cursor()
        print("Database created and Successfully Connected to SQLite")
        sqlite_select_Query = "select sqlite_version();"
        cursor.execute(sqlite_select_Query)
        record = cursor.fetchall()
        print("SQLite Database Version is: ", record)
        cursor.close()

    except sqlite3.Error as error:
        print("Error while connecting to sqlite", error)
    finally:
        if (sqliteConnection):
            sqliteConnection.close()
            print("The SQLite connection is closed\n")

def createTable():
    
    try:
        sqliteConnection = sqlite3.connect('Lab1_SQLite.db')
    
        cursor = sqliteConnection.cursor()
        
        cursor.execute('CREATE TABLE IF NOT EXISTS Database(Id REAL, year REAL, medianTemperature REAL)')
        print("Successfully Connected to SQLite")
        
        sqliteConnection.commit()
        print("SQLite table created")
    
        cursor.close()
    except sqlite3.Error as error:
        print("Error while creating a sqlite table", error)
    finally:
        if (sqliteConnection):
            sqliteConnection.close()
            print("sqlite connection is closed\n")
            
def insert(Id, year,medianTemperature ):
    try:
        sqliteConnection = sqlite3.connect('Lab1_SQLite.db')
        cursor = sqliteConnection.cursor()
        print("Connected to SQLite")
        
        cursor.execute(" INSERT INTO Database(Id, year, medianTemperature) VALUES (?, ?, ?)", (Id, year, medianTemperature))
        
        sqliteConnection.commit()
        cursor.close()
        
    except sqlite3.Error as error:
        print("Failed to insert blob data into sqlite table", error)
    finally:
        if (sqliteConnection):
            sqliteConnection.close()
            print("the sqlite connection is closed\n")


def selected(value):
    if(value == "XY Plot"):
        Lab1BackEnd.createXYPlot(tempDict)
    elif(value == "Bar Chart"):
        Lab1BackEnd.createBarChart(tempDict)
    elif(value == "Linear Regression"):
        Lab1BackEnd.createLinearRegression(tempDict)


if __name__ == '__main__':
    main()


