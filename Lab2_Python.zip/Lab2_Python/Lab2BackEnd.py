from urllib.request import urlopen
import requests
from bs4 import BeautifulSoup
import re
from collections import namedtuple
from collections import defaultdict
import Lab1BackEnd
from tkinter import *
import tkinter.messagebox
import sqlite3
from tkinter import messagebox

def scrapeData(countryNames, Emissions1990,Emissions2005,Emissions2017 
               ,Percentage_2017,ChangeFrom1990To2017,PerLandArea,PerCapita):

    html = urlopen('https://en.wikipedia.org/wiki/List_of_countries_by_carbon_dioxide_emissions')
    soup = BeautifulSoup(html, 'html.parser') 
    
  
    rows_list = soup.find_all('tr')
    
    
    countryList = []
    count = 0
    for a in rows_list:
        if(count>=6):
            countryList.append(a)
        count = count +1
    
    for x in range(0, len(countryList)):
        nextList = countryList[x].find_all('td')
        
        if(len(nextList) == 8):
            countryNames.append(nextList[0].a.text)
            Emissions1990.append(nextList[1].text)
            Emissions2005.append(nextList[2].text)
            Emissions2017.append(nextList[3].text)
            Percentage_2017.append(nextList[4].text)
            ChangeFrom1990To2017.append(nextList[5].text)
            PerLandArea.append(nextList[6].text)
            PerCapita .append(nextList[7].text)
    
def connectToDataBase():
    try:
        sqliteConnection = sqlite3.connect('Lab2_SQLite.db')
        cursor = sqliteConnection.cursor()
        print("Database created and Successfully Connected to SQLite")
        sqlite_select_Query = "select sqlite_version();"
        cursor.execute(sqlite_select_Query)
        record = cursor.fetchall()
        print("SQLite Database Version is: ", record)
        cursor.close()

    except sqlite3.Error as error:
        print("Error while connecting to sqlite", error)
    finally:
        if (sqliteConnection):
            sqliteConnection.close()
            print("The SQLite connection is closed\n")

def createTable():
    
    try:
        sqliteConnection = sqlite3.connect('Lab2_SQLite.db')
    
        cursor = sqliteConnection.cursor()
        
        #cursor.execute('CREATE TABLE IF NOT EXISTS Database(Id REAL, year REAL, medianTemperature REAL)')
        cursor.execute(
            'CREATE TABLE IF NOT EXISTS Database(Id REAL, Country REAL, CO2_1990_Emission REAL, CO2_2005_Emission REAL, CO2_2017_Emission REAL, Percentage2017 REAL, PercentageChangeFrom1990 REAL, PerLandArea REAL, PerCapita REAL )')
        print("Successfully Connected to SQLite")
        
        sqliteConnection.commit()
        print("SQLite table created")
    
        cursor.close()
    except sqlite3.Error as error:
        print("Error while creating a sqlite table", error)
    finally:
        if (sqliteConnection):
            sqliteConnection.close()
            print("sqlite connection is closed\n")
            
def insert(Id, countryName, emission1990, emission2005, emission2017, 
           percentage2017, percentageChangeFrom1990 ,perLandArea, perCapita):
    try:
        sqliteConnection = sqlite3.connect('Lab2_SQLite.db')
        cursor = sqliteConnection.cursor()
        print("Connected to SQLite")
        
        cursor.execute(" INSERT INTO Database(Id, Country, CO2_1990_Emission, CO2_2005_Emission, CO2_2017_Emission, Percentage2017, PercentageChangeFrom1990, PerLandArea, PerCapita) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
                       ,(Id, countryName, emission1990, emission2005, emission2017, 
                          percentage2017, percentageChangeFrom1990 ,perLandArea, perCapita))
        
        sqliteConnection.commit()
        cursor.close()
        
    except sqlite3.Error as error:
        print("Failed to insert blob data into sqlite table", error)
    finally:
        if (sqliteConnection):
            sqliteConnection.close()
            print("the sqlite connection is closed\n")
            
            
def sort():
    try:
        sqliteConnection = sqlite3.connect('Lab2_SQLite.db')
        cursor = sqliteConnection.cursor()
        print("Connected to SQLite")
        
        cursor.execute("SELECT * from DATABASE ORDER BY Percentage2017")
        
        print("\n\nSORTED DATA\n\n")
        print(cursor.fetchall())
        
        print("\n\n")
        sqliteConnection.commit()
        cursor.close()
        
    except sqlite3.Error as error:
        print("Failed to sort data", error)
    finally:
        if (sqliteConnection):
            sqliteConnection.close()
            print("the sqlite connection is closed\n")
            
def getTop10(countryNames,percentage2017):
    floatList = [] 
    topTenList = []
    for x in percentage2017:
        str1 = x[0:4]
        floatStr1 = (float)(str1)
        floatList.append(floatStr1)

    floatList.sort(reverse=True)
    for x in range(0,10):
        topTenList.append(floatList[x])
    print(topTenList)
    return topTenList
  
   
            
def __getitem__(yearNumber):
    try:
        sqliteConnection = sqlite3.connect('Lab1_SQLite.db')
        cursor = sqliteConnection.cursor()
        print("Connected to SQLite")

        sqlite_select_query = """SELECT * from Database"""
        cursor.execute(sqlite_select_query)
        records = cursor.fetchall()
        print("Printing each row")
        for row in records:
            if(int(row[1]) == int(yearNumber) ):
                return row[2]

        cursor.close()

    except sqlite3.Error as error:
        print("Failed to read data from sqlite table", error)
    finally:
        if (sqliteConnection):
            sqliteConnection.close()
            print("The SQLite connection is closed")