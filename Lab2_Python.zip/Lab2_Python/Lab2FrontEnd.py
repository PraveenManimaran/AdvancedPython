import Lab2BackEnd
from urllib.request import urlopen
import requests
from bs4 import BeautifulSoup
import re
from collections import namedtuple
from collections import defaultdict
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.lines as lines
import matplotlib.patches as patches
import matplotlib.path as path
from scipy.interpolate import *
from pylab import * 




def main():  

    countryNames = []
    Emissions1990 = []
    Emissions2005 = []
    Emissions2017 = []
    Percentage_2017 = []
    ChangeFrom1990To2017 = []
    PerLandArea = []
    PerCapita = []
    topTenList = []
    Lab2BackEnd.scrapeData(countryNames, Emissions1990,Emissions2005,Emissions2017 
                           ,Percentage_2017,ChangeFrom1990To2017,PerLandArea,PerCapita)
    
    Lab2BackEnd.connectToDataBase()
    Lab2BackEnd.createTable()
    
    
    for x in range(0, len(countryNames)):
        Lab2BackEnd.insert(x+1,countryNames[x],Emissions1990[x],Emissions2005[x]
                           ,Emissions2017[x],Percentage_2017[x]
                           ,ChangeFrom1990To2017[x],PerLandArea[x],PerCapita[x])

    Lab2BackEnd.sort()
    
    topTenList = Lab2BackEnd.getTop10(countryNames,Percentage_2017 )
    plotData(topTenList)
    
    
def plotData(topTenList):
    sum = 0
    for x in topTenList:
        sum = sum + x
    restOfData = 100 -sum
    topTenList.append(restOfData)
    # Pie chart, where the slices will be ordered and plotted counter-clockwise:
    labels = 'China', 'United States', 'Europe', 'India','Russia', 'Japan', 'Germany', 'South Korea', 'Iran', 'Saudi Arabia', 'Rest Of Data'
    #sizes = [15, 30, 45, 10]
    explode = (0.1, 0.1, 0.1, 0.1, 0.1, 0.1,0.1,0.1,0.1,0.1, 0.1)  # only "explode" the 2nd slice (i.e. 'Hogs')
    
    fig1, ax1 = plt.subplots()
    ax1.pie(topTenList, explode=explode, labels=labels, autopct='%1.1f%%',
            shadow=True, startangle=90)
    ax1.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
    
    plt.show()
     
if __name__ == '__main__':
    main()
