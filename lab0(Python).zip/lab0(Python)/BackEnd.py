from collections import namedtuple
from collections import defaultdict

import re

        
def readCo2HTMLFile(str):
    
    file = open(str, 'r')
    avgEmissionLevel = namedtuple("AverageCo2Level", ('year', 'Co2Level') )
    co2Dict = defaultdict()
    co2Levels = []
    tempDict = defaultdict()
    
        
    #skip first four lines using List Comprehension
    [file.readline().strip for i in range(4)]
   
        
        
    reachedEnd = False
    
    #While loop will continue until it reaches the end
    while(reachedEnd == False):
        
        
        string1 = file.readline().strip()
        if(re.search('</TABLE>', string1) == None):
            
            #Finding year number
            yearRegEx = re.compile(r'\d\d\d\d<')
            
            matches1 = yearRegEx.findall(string1);
            strYear = matches1[0]
            strYear = strYear[0:4]
            

            #Finding average Co2 level
            avgCo2RegEx= re.compile(r'>\d\d\d.\d\d')
    
            matches2 = avgCo2RegEx.findall(string1);
            strCo2 = matches2[0]
            strCo2 = strCo2[1:7]
            
            co2Levels.append(strCo2)
            
            #Finding month
            
            if(strYear != '2019'):
                monthRegEx = re.compile(r'>12<')
                matches3 = monthRegEx.findall(string1);
            else:
                monthRegEx = re.compile(r'>11<')
                matches3 = monthRegEx.findall(string1);
            
            
            strMonth = ''
            if(len(matches3) > 0):
                strMonth = matches3[0]
                strMonth = strMonth[1:3]
                average = calcAverage(strYear, co2Levels)
                
                #Setting Values to named tuple and default dictionary
                namedTuple1 = avgEmissionLevel(year = strYear,Co2Level = average)
                co2Dict[namedTuple1.year] = namedTuple1.Co2Level
                
 
        else:
           reachedEnd = True
           
        
    return co2Dict
        
 
def calcAverage(strYear, co2Levels):
    
    sum = 0.0
    
    for x in co2Levels:
        sum = sum + (float)(x)
        
    total = sum/(len(co2Levels))
    total = round(total, 2)
    
    
    #resetting list of co2 emission values
    co2Levels.clear()
    return total

def readTempHTMLFile(str):
    file = open(str, 'r')
    tempDict = defaultdict()
    
    reachedEnd = False
    
    #skip first four lines using List Comprehension
    [file.readline().strip for i in range(5)]
    
    while(reachedEnd == False):
        
        string1 = file.readline().strip()
       # print(string1)
        if(re.search('</TABLE>', string1) == None):   
            
            #Finding year number
            yearRegEx = re.compile(r'\d\d\d\d<')
            
            matches1 = yearRegEx.findall(string1);
            strYear = matches1[0]
            strYear = strYear[0:4]
            
            
            #Finding median temperature
            tempRegEx = re.split('</TD><TD>', string1)
            median = (float)(tempRegEx[1])
            
            
            #Put year and median into default dictionary
            tempDict[strYear] = median
            
        else:
            reachedEnd = True
            
    return tempDict
   
       
    






















