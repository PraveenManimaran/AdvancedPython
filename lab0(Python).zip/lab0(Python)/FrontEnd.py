from collections import namedtuple
from collections import defaultdict

import BackEnd
import re


def main():  

    #create default dictionaries
    co2Dict = defaultdict()
    tempDict = defaultdict()
    
    #CHANGE PATH NAME!
    co2Dict =  BackEnd.readCo2HTMLFile("/Users/praveenmanimaran/Desktop/Co2.html")
    tempDict = BackEnd.readTempHTMLFile("/Users/praveenmanimaran/Desktop/Temperature.html")
    
    #Call output methods to display results
    outputResults(co2Dict, tempDict)
    outputOverlapping(co2Dict, tempDict)
      
    
def outputResults(co2Dict, tempDict):
    print("Listing year and its average Co2 Emission Levels: \n")
    
    for key1 in co2Dict:
        print("Year: ", key1, " Average Co2 Emission Level: ", co2Dict[key1])
    print()
    print("Listing year and median temperatures\n")
    for key2 in tempDict:
        print("Year: ", key2, " Median Temperature: ", tempDict[key2])
    print('\n\n\n')
        
def outputOverlapping(co2Dict, tempDict):
    print("DATA OVERLAPPING RESULTS: ")
    print("\n")
    newDict = {} 
    for key, value in tempDict.items(): 
        newDict.setdefault(value, set()).add(key)
    
    #using lambda expression and filter iterator
    result = filter(lambda x: len(x)>1, newDict.values()) 
    listResult = list(result)
  
    
    for x in listResult:
        for y in x:
            m = float(y)
            
            print("Year: ", y," Median Temperature ", tempDict[y])
            if(m>=1959):
                print("Average Co2 Emission Level for",y, ":", co2Dict[y])
                print()
            else:
                print("Average Co2 Emission Level for", y, ": NOT FOUND")
                print()
        print("\n")
 
if __name__ == '__main__':
    main()