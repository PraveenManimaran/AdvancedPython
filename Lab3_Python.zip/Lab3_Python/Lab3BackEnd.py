from urllib.request import urlopen
import requests
from bs4 import BeautifulSoup
import re
from collections import namedtuple
from collections import defaultdict
from tkinter import *
import tkinter.messagebox
import sqlite3
from tkinter import messagebox
import threading
import time

def scrapeData(year, CO2Level, CH4Level, N2OLevel, CFC12Level, CFC11Level, Minor_15Level, AggiLevel):

    html = urlopen('https://www.esrl.noaa.gov/gmd/aggi/aggi.html')
    
    #https://en.wikipedia.org/wiki/List_of_countries_by_carbon_dioxide_emissions
    soup = BeautifulSoup(html, 'html.parser') 
    
  
    rows_list = soup.find_all('tr')
    
   # print(rows_list)
    yearList = []
    count = 0
    for a in rows_list:
        if(count>=11):
            yearList.append(a)
        count = count +1
    
    
    
    for x in range(0, len(yearList)):
        nextList = yearList[x].find_all('td') 
        #print(len(nextList))
        if(len(nextList) == 11):
                year.append(nextList[0].text)
                CO2Level.append(nextList[1].text)
                CH4Level.append(nextList[2].text)
                N2OLevel.append(nextList[3].text)
                CFC12Level.append(nextList[4].text)
                CFC11Level.append(nextList[5].text)
                Minor_15Level.append(nextList[6].text)
                AggiLevel.append(nextList[9].text)
                
def connectToDataBase():
    try:
        sqliteConnection = sqlite3.connect('Lab3_SQLite.db')
        cursor = sqliteConnection.cursor()
        print("Database created and Successfully Connected to SQLite")
        sqlite_select_Query = "select sqlite_version();"
        cursor.execute(sqlite_select_Query)
        record = cursor.fetchall()
        print("SQLite Database Version is: ", record)
        cursor.close()

    except sqlite3.Error as error:
        print("Error while connecting to sqlite", error)
    finally:
        if (sqliteConnection):
            sqliteConnection.close()
            print("The SQLite connection is closed\n")

def createTable():
    
    try:
        sqliteConnection = sqlite3.connect('Lab3_SQLite.db')
    
        cursor = sqliteConnection.cursor()
        
        #cursor.execute('CREATE TABLE IF NOT EXISTS Database(Id REAL, year REAL, medianTemperature REAL)')
        cursor.execute(
            'CREATE TABLE IF NOT EXISTS Database(Id REAL, Year REAL, CO2_Level REAL, CH4_Level REAL, N2O_Level REAL, CFC12_Level REAL, CFC11_Level REAL, Minor_15 REAL, AggiLevel REAL )')
        print("Successfully Connected to SQLite")
        
        sqliteConnection.commit()
        print("SQLite table created")
    
        cursor.close()
    except sqlite3.Error as error:
        print("Error while creating a sqlite table", error)
    finally:
        if (sqliteConnection):
            sqliteConnection.close()
            print("sqlite connection is closed\n")
            
def insert(Id,year, CO2Level, CH4Level, N2OLevel, CFC12Level, CFC11Level, Minor_15Level, AggiLevel):
    try:
        sqliteConnection = sqlite3.connect('Lab3_SQLite.db')
        cursor = sqliteConnection.cursor()
        print("Connected to SQLite")
        
        cursor.execute(" INSERT INTO Database(Id, Year, CO2_Level, CH4_Level, N2O_Level, CFC12_Level, CFC11_Level, Minor_15, AggiLevel) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
                       ,(Id,year, CO2Level, CH4Level, N2OLevel, CFC12Level, CFC11Level, Minor_15Level, AggiLevel))
        
        sqliteConnection.commit()
        cursor.close()
        
    except sqlite3.Error as error:
        print("Failed to insert blob data into sqlite table", error)
    finally:
        if (sqliteConnection):
            sqliteConnection.close()
            print("the sqlite connection is closed\n")
            
def getCO2Values(yearNumber, CO2Level2):
    try:
        sqliteConnection = sqlite3.connect('Lab3_SQLite.db')
        cursor = sqliteConnection.cursor()
        print("Connected to SQLite")

        sqlite_select_query = """SELECT * from Database"""
        cursor.execute(sqlite_select_query)
        records = cursor.fetchall()
        print("Printing each row")
        for row in records:
            if(int(row[1]) == int(yearNumber) ):
                CO2Level2.append(row[2])
                return row[2]

        cursor.close()

    except sqlite3.Error as error:
        print("Failed to read data from sqlite table", error)
    finally:
        if (sqliteConnection):
            sqliteConnection.close()
            print("The SQLite connection is closed")    
            
def getCH4Values(yearNumber, CH4Level2):
    try:
        sqliteConnection = sqlite3.connect('Lab3_SQLite.db')
        cursor = sqliteConnection.cursor()
        print("Connected to SQLite")

        sqlite_select_query = """SELECT * from Database"""
        cursor.execute(sqlite_select_query)
        records = cursor.fetchall()
        print("Printing each row")
        for row in records:
            if(int(row[1]) == int(yearNumber) ):
                CH4Level2.append(row[3])
                return row[3]

        cursor.close()

    except sqlite3.Error as error:
        print("Failed to read data from sqlite table", error)
    finally:
        if (sqliteConnection):
            sqliteConnection.close()
            print("The SQLite connection is closed")  
            

def getN2OValues(yearNumber, N2OLevel2):
    try:
        sqliteConnection = sqlite3.connect('Lab3_SQLite.db')
        cursor = sqliteConnection.cursor()
        print("Connected to SQLite")

        sqlite_select_query = """SELECT * from Database"""
        cursor.execute(sqlite_select_query)
        records = cursor.fetchall()
        print("Printing each row")
        for row in records:
            if(int(row[1]) == int(yearNumber) ):
                N2OLevel2.append(row[4])
                return row[4]

        cursor.close()

    except sqlite3.Error as error:
        print("Failed to read data from sqlite table", error)
    finally:
        if (sqliteConnection):
            sqliteConnection.close()
            print("The SQLite connection is closed")  
            
            
def getCFC12Values(yearNumber, CFC12Level2):
    try:
        sqliteConnection = sqlite3.connect('Lab3_SQLite.db')
        cursor = sqliteConnection.cursor()
        print("Connected to SQLite")

        sqlite_select_query = """SELECT * from Database"""
        cursor.execute(sqlite_select_query)
        records = cursor.fetchall()
        print("Printing each row")
        for row in records:
            if(int(row[1]) == int(yearNumber) ):
                CFC12Level2.append(row[5])
                return row[5]

        cursor.close()

    except sqlite3.Error as error:
        print("Failed to read data from sqlite table", error)
    finally:
        if (sqliteConnection):
            sqliteConnection.close()
            print("The SQLite connection is closed")  
            
def getCFC11Values(yearNumber, CFC11Level2):
    try:
        sqliteConnection = sqlite3.connect('Lab3_SQLite.db')
        cursor = sqliteConnection.cursor()
        print("Connected to SQLite")

        sqlite_select_query = """SELECT * from Database"""
        cursor.execute(sqlite_select_query)
        records = cursor.fetchall()
        print("Printing each row")
        for row in records:
            if(int(row[1]) == int(yearNumber) ):
                CFC11Level2.append(row[6])
                return row[6]

        cursor.close()

    except sqlite3.Error as error:
        print("Failed to read data from sqlite table", error)
    finally:
        if (sqliteConnection):
            sqliteConnection.close()
            print("The SQLite connection is closed")  
            
def getMinor15Values(yearNumber, Minor_15Level2):
    try:
        sqliteConnection = sqlite3.connect('Lab3_SQLite.db')
        cursor = sqliteConnection.cursor()
        print("Connected to SQLite")

        sqlite_select_query = """SELECT * from Database"""
        cursor.execute(sqlite_select_query)
        records = cursor.fetchall()
        print("Printing each row")
        for row in records:
            if(int(row[1]) == int(yearNumber) ):
                Minor_15Level2.append(row[7])
                return row[7]

        cursor.close()

    except sqlite3.Error as error:
        print("Failed to read data from sqlite table", error)
    finally:
        if (sqliteConnection):
            sqliteConnection.close()
            print("The SQLite connection is closed")  


            

   
            
