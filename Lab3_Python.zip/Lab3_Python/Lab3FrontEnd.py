import Lab3BackEnd
from urllib.request import urlopen
import requests
from bs4 import BeautifulSoup
import re
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.lines as lines
import matplotlib.patches as patches
import matplotlib.path as path
from scipy.interpolate import *
from pylab import * 
import threading
import time

def main():  

    year = []
    CO2Level= []
    CH4Level = []
    N2OLevel = [] 
    CFC12Level = []
    CFC11Level = [] 
    Minor_15Level = [] 
    AggiLevel= []
    Lab3BackEnd.scrapeData(year, CO2Level, CH4Level, N2OLevel, CFC12Level,
                           CFC11Level, Minor_15Level, AggiLevel)
    
    Lab3BackEnd.connectToDataBase()
    Lab3BackEnd.createTable()
    
    
    for x in range(0, len(year)):
        Lab3BackEnd.insert(x+1,year[x],CO2Level[x],CH4Level[x]
                           ,N2OLevel[x],CFC12Level[x]
                           ,CFC11Level[x],Minor_15Level[x],AggiLevel[x])
        
   # print(Lab3BackEnd.getCO2Values(1980))
    
    CO2Level2= []
    CH4Level2 = []
    N2OLevel2 = [] 
    CFC12Level2 = []
    CFC11Level2 = [] 
    Minor_15Level2 = [] 
   # createLinearRegression(year, CO2Level)
    
    for a in range(1979, 2020):
        CO2Thread = threading.Thread(target = Lab3BackEnd.getCO2Values, args = (a,CO2Level2))
        CO2Thread.start()
        CO2Thread.join()
        
    CO2Thread = threading.Thread(target = createLinearRegression, args = (year,CO2Level2))
    CO2Thread.start()
    CO2Thread.join()    
        
    for b in range(1979, 2020):
        CH4Thread = threading.Thread(target = Lab3BackEnd.getCH4Values, args = (b,CH4Level2))
        CH4Thread.start()
        CH4Thread.join()
    CH4Thread = threading.Thread(target = createLinearRegression, args = (year,CH4Level2))
    CH4Thread.start()
    CH4Thread.join()    
        
    for c in range(1979, 2020):
        N2OThread = threading.Thread(target = Lab3BackEnd.getN2OValues, args = (c,N2OLevel2))
        N2OThread.start()
        N2OThread.join()
    N2OThread = threading.Thread(target = createLinearRegression, args = (year,N2OLevel2))
    N2OThread.start()
    N2OThread.join()
    
    for d in range(1979, 2020):
        CFC12Thread = threading.Thread(target = Lab3BackEnd.getCFC12Values, args = (d,CFC12Level2))
        CFC12Thread.start()
        CFC12Thread.join()
    CFC12Thread = threading.Thread(target = createLinearRegression, args = (year,CFC12Level2))
    CFC12Thread.start()
    CFC12Thread.join()    
    
    for e in range(1979, 2020):
        CFC11Thread = threading.Thread(target = Lab3BackEnd.getCFC11Values, args = (e,CFC11Level2))
        CFC11Thread.start()
        CFC11Thread.join()
    CFC11Thread = threading.Thread(target = createLinearRegression, args = (year,CFC11Level2))
    CFC11Thread.start()
    CFC11Thread.join()
     
    for f in range(1979, 2020):
        Minor_15Thread = threading.Thread(target = Lab3BackEnd.getMinor15Values, args = (f,Minor_15Level2))
        Minor_15Thread.start()
        Minor_15Thread.join()
    Minor_15Thread = threading.Thread(target = createLinearRegression, args = (year,Minor_15Level2))
    Minor_15Thread.start()
    Minor_15Thread.join()
        
    
def createLinearRegression(year, list1):   
    years = []
    list2 = []
    
    for a in range(0, len(list1)):
        list2.append((float)(list1[a]))
              
    for b in range(0, len(year)):
        years.append ( (float) (year[b]) )
    
    coef= np.polyfit(years, list2, 1)
    poly1d_fn = np.poly1d(coef)
    
    plt.plot(years,list2, 'yo',years, poly1d_fn(years))
    plt.show()
    print("\n\n\n")
    print("y=",coef[0],"x", coef[1])
    print("\n\n")
   
   
if __name__ == '__main__':
    main()
   # y = threading.Thread(target = Lab3BackEnd.createTable, args = ())
